<?php
$db_hostname='localhost';
$db_database='';
$db_username='';
$db_password='';
?>
