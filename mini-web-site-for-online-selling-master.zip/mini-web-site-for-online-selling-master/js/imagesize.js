//change size of picture on click

function size(id){
	if(id.width=="400"){
		id.width="700";
	} else id.width="400";
}
